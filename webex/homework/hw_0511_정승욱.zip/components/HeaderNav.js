export default {
  template: `<header>
                <router-link to="/"> <img src="./img/ssafy_logo.png" /></router-link>
                <h1 class="title">부서 관리 v.3</h1>
            </header>`,
};
