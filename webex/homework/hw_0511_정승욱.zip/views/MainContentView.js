export default {
  template: `<div>
                <ul>
                    <li><router-link to="/dept/regist">부서 등록</router-link></li>
                    <li><router-link to="/dept/list">부서 목록</router-link></li>
                </ul>
            </div>`,
};
