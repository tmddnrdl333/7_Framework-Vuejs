<template>
  <div>
    <img alt="Vue logo" src="@/assets/ssafy_logo.png" /><br />
    <router-link to="/">HOME</router-link> |
    <router-link to="/">LOG IN (미구현)</router-link>
    <hr />
  </div>
</template>

<script>
export default {};
</script>

<style></style>
