<template>
  <div>
    <h1 class="underline">부서 목록</h1>
    <table>
      <colgroup>
        <col style="width: 10%" />
        <col style="width: 20%" />
        <col style="width: 40%" />
        <col style="width: 30%" />
      </colgroup>
      <thead>
        <tr>
          <th>번호</th>
          <th>부서번호</th>
          <th>부서명</th>
          <th>지역</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(dept, index) in depts" :key="dept.deptNo">
          <td>{{ index + 1 }}</td>
          <td>{{ dept.deptNo }}</td>
          <td>
            <router-link :to="'/dept/detail/' + dept.deptNo">{{
              dept.dName
            }}</router-link>
          </td>
          <td>{{ dept.loc }}</td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
import http from "@/api/http.js";
export default {
  data() {
    return {
      depts: [], // 백엔드 통신 후의 데이터로 채워짐!
    };
  },
  methods: {
    getDepts() {
      // axios 이용해서 백엔드 통신후 자신의 depts 데이터 채우는 작업!
      http
        .get("")
        .then((response) => (this.depts = response.data))
        .catch((error) => alert(error));
    },
  },
  created() {
    this.getDepts();
  },
};
</script>

<style></style>
