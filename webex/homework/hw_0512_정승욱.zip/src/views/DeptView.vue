<template>
  <div>
    <h3>DEPT VIEW</h3>
    <router-view></router-view>
  </div>
</template>

<script>
export default {};
</script>

<style></style>
