export default {
  GET_DEPTS: "getDepts",
  GET_DEPT: "getDept",
  REGIST_DEPT: "registDept",
  MODIFY_DEPT: "modifyDept",
  DELETE_DEPT: "deleteDept",
  SET_DEPTS: "setDepts",
  SET_DEPT: "setDept",
};
