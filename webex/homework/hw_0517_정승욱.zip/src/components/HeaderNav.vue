<template>
  <header>
    <router-link to="/"><img src="@/assets/img/ssafy_logo.png" /></router-link>
    <h1 class="ttile">부서 관리</h1>
  </header>
</template>

<script>
export default {};
</script>

<style></style>
