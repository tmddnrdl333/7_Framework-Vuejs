<template>
  <div>
    <ul>
      <li><router-link to="/dept/regist_form">부서 등록</router-link></li>
      <li><router-link to="/dept/list">부서 목록</router-link></li>
    </ul>
  </div>
</template>

<script>
export default {};
</script>

<style></style>
